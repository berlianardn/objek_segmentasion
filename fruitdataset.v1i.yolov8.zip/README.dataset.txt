# fruitdataset > 2025-06-20 9:10am
https://universe.roboflow.com/pawan-joshi-icz4m/fruitdataset-qo5mn

Provided by a Roboflow user
License: CC BY 4.0

